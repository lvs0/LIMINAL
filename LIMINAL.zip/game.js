// LIMINAL - Jeu d'horreur psychologique 3D
// Moteur Three.js avec shaders personnalisés

class LiminalGame {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.player = { x: 0, y: 1.6, z: 5, rotX: 0, rotY: 0 };
        this.keys = {};
        this.sanity = 100;
        this.objects = [];
        this.interactables = [];
        this.currentChapter = 0;
        this.time = 0;
        this.glitchIntensity = 0;
        
        this.narrative = [
            "Vous vous réveillez dans un couloir qui ne mène nulle part. Les murs respirent silencieusement.",
            "Cet endroit n'existe pas. C'est une projection de votre culpabilité, fossilisée dans l'espace-temps.",
            "Vous entendez des murmures. Ce sont vos propres pensées, échos d'une vie que vous avez essayé d'oublier.",
            "Chaque pas vous rapproche de la vérité. Chaque vérité vous efface un peu plus.",
            "Il n'y a pas de monstre ici. Seulement vous, et tout ce que vous avez enfoui."
        ];
        
        this.init();
    }

    init() {
        // Setup Three.js
        this.scene = new THREE.Scene();
        this.scene.fog = new THREE.FogExp2(0x000000, 0.03);
        
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.camera.position.set(0, 1.6, 5);
        
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.getElementById('game-container').appendChild(this.renderer.domElement);
        
        // Lumière ambiente faible
        const ambientLight = new THREE.AmbientLight(0x111111, 0.2);
        this.scene.add(ambientLight);
        
        this.setupWorld();
        this.setupShaders();
        this.setupEvents();
        this.setupAudio();
        
        // Remove loading
        setTimeout(() => {
            document.getElementById('loading').style.opacity = 0;
            setTimeout(() => document.getElementById('loading').remove(), 2000);
        }, 1000);
        
        // Start button
        document.getElementById('start-btn').addEventListener('click', () => {
            document.getElementById('title-card').style.opacity = 0;
            setTimeout(() => {
                document.getElementById('title-card').remove();
                this.lockPointer();
                this.showNarrative(0);
            }, 3000);
        });
    }

    setupWorld() {
        // Texture procédurale pour murs
        const wallTexture = this.createProceduralTexture('#1a1a1a', '#0a0a0a');
        const floorTexture = this.createProceduralTexture('#0d0d0d', '#050505');
        
        // Matériaux
        const wallMaterial = new THREE.MeshStandardMaterial({
            map: wallTexture,
            roughness: 0.9,
            metalness: 0.1,
            color: 0x333333
        });
        
        const floorMaterial = new THREE.MeshStandardMaterial({
            map: floorTexture,
            roughness: 0.5,
            metalness: 0.3,
            color: 0x111111
        });
        
        // Création du labyrinthe procédural
        this.createCorridor(0, 0, 0, 10, 3, 4, wallMaterial, floorMaterial);
        this.createCorridor(0, 0, -10, 10, 3, 4, wallMaterial, floorMaterial, Math.PI / 2);
        this.createRoom(10, 0, -10, 8, 4, 8, wallMaterial, floorMaterial);
        this.createCorridor(-10, 0, 0, 15, 3, 4, wallMaterial, floorMaterial);
        
        // Objets interactifs
        this.addInteractableObject(8, 0.5, -10, 'livre', 0xff4400);
        this.addInteractableObject(-5, 1, 0, 'miroir', 0x4444ff);
        this.addInteractableObject(0, 1, -8, 'porte', 0x00ff00);
        
        // Lumières ponctuelles avec flickering
        this.addFlickeringLight(0, 2.5, 0, 0xffaa00, 5);
        this.addFlickeringLight(10, 2.5, -10, 0xff4400, 3);
        this.addFlickeringLight(-5, 2.5, 0, 0x4444ff, 4);
        
        // Particules atmosphériques
        this.createAtmosphericParticles();
        
        // Horloge anormale
        this.createAnomalousClock(5, 2, -2);
    }

    createProceduralTexture(color1, color2) {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');
        
        // Bruit de Perlin simplifié
        for (let i = 0; i < 50000; i++) {
            const x = Math.random() * 512;
            const y = Math.random() * 512;
            const size = Math.random() * 3;
            ctx.fillStyle = Math.random() > 0.5 ? color1 : color2;
            ctx.fillRect(x, y, size, size);
        }
        
        const texture = new THREE.CanvasTexture(canvas);
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;
        return texture;
    }

    createCorridor(x, y, z, length, height, width, wallMat, floorMat, rotation = 0) {
        const group = new THREE.Group();
        
        // Sol
        const floor = new THREE.Mesh(new THREE.PlaneGeometry(width, length), floorMat);
        floor.rotation.x = -Math.PI / 2;
        floor.position.y = 0;
        floor.receiveShadow = true;
        group.add(floor);
        
        // Plafond
        const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(width, length), wallMat);
        ceiling.rotation.x = Math.PI / 2;
        ceiling.position.y = height;
        group.add(ceiling);
        
        // Murs
        const wallGeo = new THREE.PlaneGeometry(length, height);
        
        const leftWall = new THREE.Mesh(wallGeo, wallMat);
        leftWall.position.set(-width/2, height/2, 0);
        leftWall.rotation.y = Math.PI / 2;
        leftWall.receiveShadow = true;
        group.add(leftWall);
        
        const rightWall = new THREE.Mesh(wallGeo, wallMat);
        rightWall.position.set(width/2, height/2, 0);
        rightWall.rotation.y = -Math.PI / 2;
        rightWall.receiveShadow = true;
        group.add(rightWall);
        
        group.position.set(x, y, z);
        if (rotation) group.rotation.y = rotation;
        
        this.scene.add(group);
        this.objects.push(group);
    }

    createRoom(x, y, z, w, h, d, wallMat, floorMat) {
        const group = new THREE.Group();
        
        // Sol et plafond
        const floor = new THREE.Mesh(new THREE.PlaneGeometry(w, d), floorMat);
        floor.rotation.x = -Math.PI / 2;
        floor.receiveShadow = true;
        group.add(floor);
        
        const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(w, d), wallMat);
        ceiling.rotation.x = Math.PI / 2;
        ceiling.position.y = h;
        group.add(ceiling);
        
        // 4 murs
        const walls = [
            { pos: [0, h/2, -d/2], rot: [0, 0, 0], size: [w, h] },
            { pos: [0, h/2, d/2], rot: [0, Math.PI, 0], size: [w, h] },
            { pos: [-w/2, h/2, 0], rot: [0, Math.PI/2, 0], size: [d, h] },
            { pos: [w/2, h/2, 0], rot: [0, -Math.PI/2, 0], size: [d, h] }
        ];
        
        walls.forEach(wall => {
            const mesh = new THREE.Mesh(new THREE.PlaneGeometry(wall.size[0], wall.size[1]), wallMat);
            mesh.position.set(...wall.pos);
            mesh.rotation.set(...wall.rot);
            mesh.receiveShadow = true;
            group.add(mesh);
        });
        
        group.position.set(x, y, z);
        this.scene.add(group);
    }

    addInteractableObject(x, y, z, type, color) {
        let geometry, material, mesh;
        
        switch(type) {
            case 'livre':
                geometry = new THREE.BoxGeometry(0.3, 0.4, 0.1);
                material = new THREE.MeshStandardMaterial({ color: 0x442211, emissive: color, emissiveIntensity: 0.2 });
                break;
            case 'miroir':
                geometry = new THREE.PlaneGeometry(1.5, 2);
                material = new THREE.MeshStandardMaterial({ 
                    color: 0x888888, 
                    metalness: 0.9, 
                    roughness: 0.1,
                    emissive: color,
                    emissiveIntensity: 0.1
                });
                break;
            case 'porte':
                geometry = new THREE.BoxGeometry(1.2, 2.2, 0.1);
                material = new THREE.MeshStandardMaterial({ color: 0x221111 });
                break;
        }
        
        mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        mesh.userData = { type: type, interacted: false };
        
        // Lumière ponctuelle
        const light = new THREE.PointLight(color, 1, 3);
        light.position.set(0, 0.5, 0.5);
        mesh.add(light);
        
        this.scene.add(mesh);
        this.interactables.push(mesh);
    }

    addFlickeringLight(x, y, z, color, intensity) {
        const light = new THREE.PointLight(color, intensity, 10);
        light.position.set(x, y, z);
        light.castShadow = true;
        light.shadow.mapSize.width = 1024;
        light.shadow.mapSize.height = 1024;
        
        // Ampoule visible
        const bulb = new THREE.Mesh(
            new THREE.SphereGeometry(0.1, 8, 8),
            new THREE.MeshBasicMaterial({ color: color })
        );
        light.add(bulb);
        
        this.scene.add(light);
        
        // Animation de flickering
        setInterval(() => {
            if (Math.random() > 0.7) {
                light.intensity = intensity * (0.3 + Math.random() * 0.7);
                setTimeout(() => light.intensity = intensity, 50 + Math.random() * 150);
            }
        }, 2000 + Math.random() * 3000);
    }

    createAtmosphericParticles() {
        const geometry = new THREE.BufferGeometry();
        const count = 1000;
        const positions = new Float32Array(count * 3);
        
        for (let i = 0; i < count * 3; i += 3) {
            positions[i] = (Math.random() - 0.5) * 50;
            positions[i+1] = Math.random() * 10;
            positions[i+2] = (Math.random() - 0.5) * 50;
        }
        
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        
        const material = new THREE.PointsMaterial({
            color: 0x666666,
            size: 0.05,
            transparent: true,
            opacity: 0.4,
            blending: THREE.AdditiveBlending
        });
        
        this.particles = new THREE.Points(geometry, material);
        this.scene.add(this.particles);
    }

    createAnomalousClock(x, y, z) {
        const group = new THREE.Group();
        
        // Cadran
        const face = new THREE.Mesh(
            new THREE.CylinderGeometry(0.5, 0.5, 0.05, 32),
            new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.5, roughness: 0.5 })
        );
        face.rotation.x = Math.PI / 2;
        group.add(face);
        
        // Aiguilles
        const handMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
        this.hourHand = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.3, 0.02), handMat);
        this.hourHand.position.z = 0.03;
        group.add(this.hourHand);
        
        this.minuteHand = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.4, 0.02), handMat);
        this.minuteHand.position.z = 0.04;
        group.add(this.minuteHand);
        
        group.position.set(x, y, z);
        this.scene.add(group);
        
        // Animation irrégulière de l'horloge
        setInterval(() => {
            this.hourHand.rotation.z = Math.random() * Math.PI * 2;
            this.minuteHand.rotation.z = Math.random() * Math.PI * 4;
        }, 1000);
    }

    setupShaders() {
        // Shader de distorsion post-processing pour effet psychédélique
        this.distortionUniforms = {
            time: { value: 0 },
            intensity: { value: 0 },
            resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) }
        };
    }

    setupEvents() {
        document.addEventListener('keydown', (e) => this.keys[e.key] = true);
        document.addEventListener('keyup', (e) => this.keys[e.key] = false);
        
        document.addEventListener('mousemove', (e) => {
            if (document.pointerLockElement) {
                this.player.rotY -= e.movementX * 0.002;
                this.player.rotX -= e.movementY * 0.002;
                this.player.rotX = Math.max(-Math.PI/2, Math.min(Math.PI/2, this.player.rotX));
            }
        });
        
        document.addEventListener('click', () => this.handleInteraction());
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'e' || e.key === 'E') {
                this.handleInteraction();
            }
        });
        
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    lockPointer() {
        this.renderer.domElement.requestPointerLock();
    }

    setupAudio() {
        // Audio procédural avec Web Audio API
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Drone ambiant
        this.createDrone();
        
        // Murmures occasionnels
        setInterval(() => {
            if (Math.random() > 0.7 && this.sanity < 80) {
                this.createWhisper();
            }
        }, 10000);
    }

    createDrone() {
        const oscillator = this.audioContext.createOscillator();
        const gain = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(60, this.audioContext.currentTime);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(200, this.audioContext.currentTime);
        
        gain.gain.setValueAtTime(0.05, this.audioContext.currentTime);
        
        oscillator.connect(filter);
        filter.connect(gain);
        gain.connect(this.audioContext.destination);
        
        oscillator.start();
        
        // Modulation subtile
        setInterval(() => {
            oscillator.frequency.linearRampToValueAtTime(
                50 + Math.random() * 20, 
                this.audioContext.currentTime + 2
            );
        }, 2000);
    }

    createWhisper() {
        const bufferSize = this.audioContext.sampleRate * 2;
        const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * 0.1;
        }
        
        const source = this.audioContext.createBufferSource();
        const gain = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        source.buffer = buffer;
        filter.type = 'bandpass';
        filter.frequency.value = 1000 + Math.random() * 2000;
        gain.gain.setValueAtTime(0, this.audioContext.currentTime);
        gain.gain.linearRampToValueAtTime(0.03, this.audioContext.currentTime + 0.5);
        gain.gain.linearRampToValueAtTime(0, this.audioContext.currentTime + 2);
        
        source.connect(filter);
        filter.connect(gain);
        gain.connect(this.audioContext.destination);
        
        source.start();
    }

    handleInteraction() {
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
        
        const intersects = raycaster.intersectObjects(this.interactables);
        
        if (intersects.length > 0 && intersects[0].distance < 3) {
            const obj = intersects[0].object;
            
            if (!obj.userData.interacted) {
                obj.userData.interacted = true;
                
                switch(obj.userData.type) {
                    case 'livre':
                        this.showNarrative("Vous ouvrez un journal poussiéreux. 'Je ne sais plus qui je suis. Les murs se rapprochent chaque nuit.'");
                        this.decreaseSanity(10);
                        break;
                    case 'miroir':
                        this.showNarrative("Le reflet ne vous ressemble pas. Il sourit quand vous froncez les sourcils.");
                        this.decreaseSanity(15);
                        break;
                    case 'porte':
                        this.showNarrative("La porte s'ouvre sur... le même couloir. La boucle se referme.");
                        this.currentChapter++;
                        this.player.x = 0;
                        this.player.z = 5;
                        break;
                }
            }
        }
    }

    showNarrative(index) {
        const narrativeEl = document.getElementById('narrative');
        narrativeEl.textContent = this.narrative[index] || "Silence. Un silence qui pèse sur votre poitrine.";
        narrativeEl.classList.add('visible');
        
        setTimeout(() => {
            narrativeEl.classList.remove('visible');
        }, 8000);
    }

    decreaseSanity(amount) {
        this.sanity = Math.max(0, this.sanity - amount);
        document.getElementById('sanity-fill').style.width = this.sanity + '%';
        
        // Effets visuels basés sur la santé mentale
        this.glitchIntensity = (100 - this.sanity) / 100;
        
        if (this.sanity < 30) {
            this.scene.fog.density = 0.05 + Math.random() * 0.02;
        }
    }

    update() {
        this.time += 0.016;
        
        // Mouvement joueur
        const speed = 0.08;
        const moveX = (this.keys['d'] ? 1 : 0) - (this.keys['a'] ? 1 : 0);
        const moveZ = (this.keys['s'] ? 1 : 0) - (this.keys['w'] ? 1 : 0);
        
        if (moveX !== 0 || moveZ !== 0) {
            const angle = this.player.rotY;
            this.player.x += (moveX * Math.cos(angle) - moveZ * Math.sin(angle)) * speed;
            this.player.z += (moveX * Math.sin(angle) + moveZ * Math.cos(angle)) * speed;
            
            // Collision simple
            this.player.x = Math.max(-20, Math.min(20, this.player.x));
            this.player.z = Math.max(-20, Math.min(20, this.player.z));
        }
        
        // Mise à jour caméra
        this.camera.position.set(this.player.x, this.player.y, this.player.z);
        this.camera.rotation.order = 'YXZ';
        this.camera.rotation.y = this.player.rotY;
        this.camera.rotation.x = this.player.rotX;
        
        // Animation particules
        if (this.particles) {
            this.particles.rotation.y += 0.001;
            const positions = this.particles.geometry.attributes.position.array;
            for (let i = 1; i < positions.length; i += 3) {
                positions[i] += Math.sin(this.time + i) * 0.01;
            }
            this.particles.geometry.attributes.position.needsUpdate = true;
        }
        
        // Distorsion psychologique
        if (this.glitchIntensity > 0 && Math.random() < this.glitchIntensity * 0.1) {
            this.camera.position.x += (Math.random() - 0.5) * 0.1;
            setTimeout(() => {
                this.camera.position.x = this.player.x;
            }, 50);
        }
        
        // Perte progressive de santé mentale
        if (this.time % 60 < 0.02) {
            this.decreaseSanity(0.5);
        }
        
        this.renderer.render(this.scene, this.camera);
        requestAnimationFrame(() => this.update());
    }
}

// Démarrage
window.onload = () => {
    const game = new LiminalGame();
    game.update();
};